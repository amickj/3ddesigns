                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3029677
Dual Horizontal Badge Holder (two id cards) by wavexx is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Simple/robust card holder for two credit-card sized badges. We use those in our biology lab to open doors and fridges. They are sturdy, hold the card securely and allow the card to be swapped very easily. The small gap between the two cards makes it work with all the RFID systems we tried.

This is a very simple remix of the great [card holder by Jori](https://www.thingiverse.com/thing:2746205). The model was cut and the handle modified in order to be able to glue two halves together. The changed model [is available here](https://cad.onshape.com/documents/c4fd6a4fc7a4b44cf7ca708b/w/5f31a364e91c36d4c43afc9a/e/7c3a6c7799bb329f6a7826ed).

Print two of those, with one copy being mirrored along the X axis (as shown in the picture!), then glue both halves together to get the final holder.

# Print Settings

Supports: Yes

Notes: 
You need supports enabled to print correctly the small overhanging slots for the card. When using slic3r, ensure good Z separation (0.25/0.3mm suggested) as otherwise they might be too hard to remove.